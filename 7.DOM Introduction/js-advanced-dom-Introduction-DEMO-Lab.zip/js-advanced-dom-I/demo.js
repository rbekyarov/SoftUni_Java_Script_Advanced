console.log('init');

function onSecondButtonClick() {
    console.log('Second button click');
}


function showText() {
    let textElement = document.getElementById('text');
    textElement.style.display = 'inline';

    let showMoreElement = document.getElementById('more');
    showMoreElement.style.display = 'none';
}
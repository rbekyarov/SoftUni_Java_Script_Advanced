# 04.02 - Grid Design

## Links

[Grid Website Design](https://www.figma.com/community/file/978648046298721882)